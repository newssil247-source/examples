
import Link from 'next/link'
export default function Layout({children}){
  return <div>
    <header className="site"><div className="wrap studio">
      <div className="logo">Newssil <span className="tag">v7 FULL-EXT</span></div>
      <nav className="nav">
        <Link href="/">ראשי</Link>
        <Link href="/live-edition">מהדורה חיה</Link>
        <Link href="/news">חדשות</Link>
        <Link href="/breaking">דחופים</Link>
        <Link href="/geo">GeoNews</Link>
        <Link href="/ai-news">AI News</Link>
        <Link href="/video">וידאו</Link>
        <Link href="/community">קהילה</Link>
        <Link href="/premium">פרימיום</Link>
        <Link href="/ads">פרסום</Link>
        <Link href="/uploads">העלאות</Link>
        <Link href="/languages">שפות</Link>
        <Link href="/push-setup">Push</Link>
        <Link href="/auth/login">התחברות</Link>
        <Link href="/admin">Admin</Link>
      </nav>
    </div></header>
    <main>{children}</main>
    <footer><div className="wrap" style={{padding:'16px 0'}}>© {new Date().getFullYear()} Newssil</div></footer>
  </div>
}
