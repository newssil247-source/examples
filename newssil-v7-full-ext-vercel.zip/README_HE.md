
# Newssil v7 — Full-Ext (Vercel Ready)
כולל: Auth, Uploads, GeoNews, CMS, פושים, Stripe, Templates, Cron, Ingestor, PWA, SEO.

## הפעלה מקומית
npm i
npm run dev
# http://localhost:3000

## פריסה ל-Vercel (שלבים)
1) העלה את התיקייה הזו: https://vercel.com/new (Upload).
2) Settings → Environment Variables → הדבק את הערכים מתוך `.env.local.sample`.
3) Deploy. קבל URL כמו https://<project>.vercel.app
4) חיבור דומיין: https://vercel.com/docs/projects/domains/add-a-domain

## Firebase — פעולות חובה
- Auth: הפעל Email/Password + Google, והוסף Authorized domains (localhost, הדומיין שלך).
- Storage Rules (הדבק בקונסול):
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /uploads/{uid}/{all=**} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.auth.uid == uid
                   && request.resource.size < 10 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*|video/.*');
    }
  }
}

## Stripe — קישורים
- Dashboard: https://dashboard.stripe.com
- API Keys: https://dashboard.stripe.com/apikeys
- Products/Prices: https://dashboard.stripe.com/products
- Checkout Docs: https://stripe.com/docs/payments/checkout

## כתובות שימושיות בפרויקט
- /auth/login — התחברות (Firebase Auth)
- /uploads — העלאת קבצים ל-Storage
- /admin — CMS + Push Center + Templates + Newsletter (מוגן Basic Auth)
- /push-setup — הרשמה לפושים
- /premium/upgrade — תשלום Stripe Checkout
- /api/ingest/rss?url=...&region=IL — יבוא RSS (צריך Firebase Admin)

## בעיות נפוצות
- storage/unauthorized → בדוק התחברות/Rules/נתיב uploads/{uid}
- auth/unauthorized-domain → הוסף דומיין ב-Firebase Auth
- CORS/Vercel WAF → אשר *.googleapis.com, *.firebaseapp.com, firebasestorage.googleapis.com
