
import { NextResponse } from 'next/server'
export const config = { matcher: ['/admin/:path*','/premium/:path*'] }
export default function middleware(req){
  const url = new URL(req.url)
  if(url.pathname.startsWith('/admin')){
    const u=process.env.ADMIN_USER, p=process.env.ADMIN_PASS
    if(u && p){
      const auth=req.headers.get('authorization')||''
      const [sch,enc]=auth.split(' '); if(sch==='Basic'){ const [uu,pp]=Buffer.from(enc||'','base64').toString().split(':'); if(uu===u&&pp===p) return NextResponse.next() }
      return new NextResponse('Auth required', { status:401, headers:{'WWW-Authenticate':'Basic realm="Newssil Admin"'} })
    }
  }
  if(url.pathname.startsWith('/premium')){
    const has = req.cookies.get('premium_ok')?.value==='1'
    if(!has) return NextResponse.redirect(new URL('/premium/upgrade', req.url))
  }
  return NextResponse.next()
}
