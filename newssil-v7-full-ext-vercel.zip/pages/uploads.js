
import { useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { getAuth, onAuthStateChanged } from 'firebase/auth'
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage'
export default function Uploads(){
  const [user,setUser]=useState(null); const [url,setUrl]=useState(''); const [progress,setProgress]=useState(0); const [status,setStatus]=useState('')
  useEffect(()=>{
    const app = initializeApp({
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY, authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
    })
    const auth=getAuth(app); return onAuthStateChanged(auth, u=>setUser(u))
  },[])
  function onFile(e){
    const f=e.target.files?.[0]; if(!f){return}
    const storage=getStorage(); const r=ref(storage, `uploads/${(user?.uid||'anon')}/${Date.now()}-${f.name}`)
    const task=uploadBytesResumable(r,f)
    task.on('state_changed', s=>{ setProgress(Math.round((s.bytesTransferred/s.totalBytes)*100)) }, err=>setStatus('שגיאה '+err.message), async()=>{
      const link=await getDownloadURL(task.snapshot.ref); setUrl(link); setStatus('הועלה ✔')
    })
  }
  return (<main className='wrap'><div className='card'><h2>העלאות</h2>
    {!user && <div className='tag'>יש להתחבר ב-/auth/login</div>}
    <input type='file' onChange={onFile} />
    <div>התקדמות: {progress}%</div>
    <div>קישור: {url? <a href={url} target='_blank' rel='noreferrer'>צפה</a> : '-'}</div>
    <div>{status}</div>
  </div></main>)
}
