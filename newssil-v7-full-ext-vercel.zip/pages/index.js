
import useSWR from 'swr'
const fetcher=(u)=>fetch(u).then(r=>r.json())
export default function Home(){
  const {data}=useSWR('/api/feed/preview',fetcher,{refreshInterval:5000})
  return (<main className='wrap'>
    <div className='card'><div className='tag'>ברייקינג</div><h3>{data?.breaking?.title||'—'}</h3></div>
    <div className='card'><div className='tag'>v7 Full-Ext</div><p>Auth, Uploads, GeoNews, CMS, פושים, Stripe, תבניות, Cron, Ingestor.</p></div>
  </main>)
}
