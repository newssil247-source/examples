
import Link from 'next/link'
import geo from '../../data/geo.json'
export default function Country({code,obj}){
  if(!obj) return <main className='wrap'><div className='card'>לא נמצאה מדינה</div></main>
  return (<main className='wrap'><div className='card'><h2>{obj.name}</h2><ul>{(obj.cities||[]).map(c=>(<li key={c}><Link href={`/geo/${code}/${encodeURIComponent(c)}`}>{c}</Link></li>))}</ul></div></main>)
}
export async function getServerSideProps(ctx){ const code=(ctx.params?.country||'').toUpperCase(); return { props:{ code, obj: geo[code]||null } } }
