
import Link from 'next/link'
import geo from '../../data/geo.json'
export default function Geo(){ return (<main className='wrap'><div className='card'><h2>GeoNews</h2><ul>{Object.entries(geo).map(([c,o])=>(<li key={c}><Link href={'/geo/'+c}>{o.name}</Link></li>))}</ul></div></main>) }
