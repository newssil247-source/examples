
export default function City({code,city}){return(<main className='wrap'><div className='card'><h2>חדשות {city} ({code})</h2><p>פיד מסונן לפי region יוצג כאן.</p></div></main>)}
export async function getServerSideProps(ctx){ const code=(ctx.params?.country||'').toUpperCase(); const city=decodeURIComponent(ctx.params?.city||''); return { props:{code,city} } }
