
import { useEffect, useState } from 'react'
const call=(u,m='GET',b)=>fetch(u,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined}).then(r=>r.json())
export default function Articles(){
  const [items,setItems]=useState([])
  const [title,setTitle]=useState(''); const [summary,setSummary]=useState('')
  const [topic,setTopic]=useState('general'); const [region,setRegion]=useState('IL')
  const [status,setStatus]=useState('draft'); const [publishAt,setPublishAt]=useState('')
  async function load(){ setItems((await call('/api/cms/articles/list')).items||[]) }
  useEffect(()=>{ load() },[])
  return (<main className='wrap'><div className='card'><h2>Articles CMS</h2>
    <div className='grid-2'>
      <input placeholder='כותרת' value={title} onChange={e=>setTitle(e.target.value)} />
      <input placeholder='תקציר' value={summary} onChange={e=>setSummary(e.target.value)} />
      <input placeholder='נושא' value={topic} onChange={e=>setTopic(e.target.value)} />
      <input placeholder='אזור (IL/US/GB...)' value={region} onChange={e=>setRegion(e.target.value)} />
      <select value={status} onChange={e=>setStatus(e.target.value)}><option value='draft'>draft</option><option value='scheduled'>scheduled</option><option value='live'>live</option></select>
      <input placeholder='publishAt (ms)' value={publishAt} onChange={e=>setPublishAt(e.target.value)} />
      <button className='btn' onClick={async()=>{ await call('/api/cms/articles/create','POST',{title,summary,topic,region,status,publishAt:publishAt?parseInt(publishAt,10):null}); setTitle(''); setSummary(''); load(); }}>שמור</button>
    </div>
    <hr className='sep'/>
    {(items||[]).map((a,i)=>(<div key={i} className='card'><div className='tag'>{a.status} • {a.topic} • {a.region}</div><h3>{a.title}</h3><p>{a.summary}</p></div>))}
  </div></main>)
}
