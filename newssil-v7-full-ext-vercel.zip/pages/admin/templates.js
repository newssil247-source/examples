
import { useEffect, useState } from 'react'
const q=(u)=>fetch(u).then(r=>r.json())
export default function Templates(){
  const [list,setList]=useState([]); const [data,setData]=useState({})
  useEffect(()=>{ (async()=>{ const j=await q('/api/templates/list'); setList(j.items||[]) })() },[])
  async function load(n){ const j=await q('/api/templates/get?name='+encodeURIComponent(n)); setData(j.data||{}) }
  return (<main className='wrap'><div className='card'><h2>Templates</h2>
    <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>{list.map(n=>(<button className='btn' onClick={()=>load(n)} key={n}>{n}</button>))}</div>
    <hr className='sep'/><pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(data,null,2)}</pre>
  </div></main>)
}
