
import { useEffect, useState } from 'react'
const call=(u,m='GET',b)=>fetch(u,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined}).then(r=>r.json())
export default function PushCenter(){
  const [stats,setStats]=useState({count:0,topics:[],regions:[]})
  const [title,setTitle]=useState(''); const [body,setBody]=useState('')
  const [regions,setRegions]=useState(''); const [topics,setTopics]=useState('')
  const [topicName,setTopicName]=useState('security'); const [topicTokens,setTopicTokens]=useState('')
  const [status,setStatus]=useState('')
  async function refresh(){ setStats(await call('/api/push/tokens/stats')) }
  useEffect(()=>{ refresh() },[])
  return (<main className='wrap'><div className='card'><h2>Push Center</h2>
    <div>מס' טוקנים: <b>{stats.count||0}</b></div>
    <hr className='sep'/>
    <input placeholder='כותרת' value={title} onChange={e=>setTitle(e.target.value)} />
    <textarea rows={3} placeholder='תוכן' value={body} onChange={e=>setBody(e.target.value)} />
    <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:8}}>
      <button className='btn' onClick={async()=>{ setStatus('שליחה...'); const j=await call('/api/pushes/send','POST',{title,body}); setStatus(`נשלחו: ${j.sent||0}`)}}>שלח לכולם</button>
      <button className='btn' onClick={async()=>{ setStatus('שליחה...'); const j=await call('/api/pushes/send-segmented','POST',{title,body,regions:regions.split(',').map(s=>s.trim()).filter(Boolean),topics:topics.split(',').map(s=>s.trim()).filter(Boolean)}); setStatus(`נשלחו: ${j.sent||0}`)}}>שלח מפולח</button>
      <button className='btn' onClick={async()=>{ const j=await call('/api/pushes/send-topic','POST',{topic:topicName,title,body}); setStatus(`נשלח ל-Topic ${topicName}`)}}>שלח Topic</button>
    </div>
    <div style={{marginTop:8}}>
      <input placeholder='אזורים (פסיקים)' value={regions} onChange={e=>setRegions(e.target.value)} />{" "}
      <input placeholder='נושאים (פסיקים)' value={topics} onChange={e=>setTopics(e.target.value)} />
    </div>
    <hr className='sep'/>
    <h3>Topic ניהול</h3>
    <input placeholder='שם Topic' value={topicName} onChange={e=>setTopicName(e.target.value)} />
    <textarea rows={3} placeholder='טוקנים (שורה לכל טוקן)' value={topicTokens} onChange={e=>setTopicTokens(e.target.value)} />
    <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
      <button className='btn' onClick={async()=>{ const tokens=topicTokens.split('\n').map(s=>s.trim()).filter(Boolean).slice(0,1000); const j=await call('/api/push/topics/subscribe','POST',{tokens,topics:[topicName]}); setStatus(`נרשמו: ${j.success||0}`)}}>Subscribe</button>
      <button className='btn' onClick={async()=>{ const tokens=topicTokens.split('\n').map(s=>s.trim()).filter(Boolean).slice(0,1000); const j=await call('/api/push/topics/unsubscribe','POST',{tokens,topics:[topicName]}); setStatus(`הוסרו: ${j.success||0}`)}}>Unsubscribe</button>
    </div>
    {status && <div className='card'>{status}</div>}
  </div></main>)
}
