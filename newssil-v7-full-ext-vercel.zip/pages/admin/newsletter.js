
import { useEffect, useState } from 'react'
const call=(u,m='GET',b)=>fetch(u,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined}).then(r=>r.json())
export default function Newsletter(){
  const [tpl,setTpl]=useState(null); const [items,setItems]=useState([])
  useEffect(()=>{ (async()=>{ const t=await call('/api/templates/get?name=newsletter'); setTpl(t.data||{}); const a=await call('/api/news?limit=12'); setItems(a.items||[]) })() },[])
  return (<main className='wrap'><div className='card'>
    <h2>Newsletter Builder</h2><div className='tag'>נושא: {tpl?.subject||'-'}</div><p>{tpl?.intro||''}</p>
    <ol>{items.map((a,i)=>(<li key={i}><b>{a.title}</b> — {a.summary}</li>))}</ol>
    <hr className='sep'/><button className='btn' onClick={async()=>{ await call('/api/jobs/daily-newsletter','POST',{}); alert('נשלח (דמו)') }}>שלח עכשיו (דמו)</button>
  </div></main>)
}
