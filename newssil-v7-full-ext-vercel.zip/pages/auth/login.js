
import { useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { getAuth, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut } from 'firebase/auth'
export default function Login(){
  const [email,setEmail]=useState(''); const [pass,setPass]=useState(''); const [user,setUser]=useState(null); const [msg,setMsg]=useState('')
  useEffect(()=>{
    const app = initializeApp({
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY, authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID, appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
    })
    const auth=getAuth(app); return onAuthStateChanged(auth, u=>setUser(u))
  },[])
  async function loginEmail(){ try{ await signInWithEmailAndPassword(getAuth(),email,pass); setMsg('מחובר') }catch(e){ setMsg(e.message) } }
  async function loginGoogle(){ try{ await signInWithPopup(getAuth(), new GoogleAuthProvider()); setMsg('מחובר') }catch(e){ setMsg(e.message) } }
  async function out(){ try{ await signOut(getAuth()); setMsg('התנתקת') }catch(e){} }
  return (<main className='wrap'><div className='card'><h2>התחברות</h2>
    <div className='grid-2'><div><input placeholder='אימייל' value={email} onChange={e=>setEmail(e.target.value)} /><input placeholder='סיסמה' type='password' value={pass} onChange={e=>setPass(e.target.value)} /><button className='btn' onClick={loginEmail}>התחבר</button></div>
    <div><button className='btn' onClick={loginGoogle}>Google</button><button className='btn' onClick={out}>התנתק</button></div></div>
    <div style={{marginTop:10}}>{user? 'מחובר כ: '+(user.email||user.uid) : 'לא מחובר'} • {msg}</div>
  </div></main>)
}
