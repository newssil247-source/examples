
import data from '../../data/languages.json'
export default function S({lang}){return(<main className='wrap'><div className='card'><h2>{lang?.name} ({lang?.english})</h2><div>{lang?.hello}</div></div></main>)}
export async function getServerSideProps(ctx){
  const s=(ctx.params?.slug||'').toLowerCase()
  const m=data.find(l=>l.english.toLowerCase().replace(/[^\w]+/g,'-')===s)||null
  return { props: { lang:m } }
}
