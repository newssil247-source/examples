
import Link from 'next/link'
import data from '../../data/languages.json'
function slug(s){return encodeURIComponent((s||'').toLowerCase().replace(/[^\w\u0590-\u05FF]+/g,'-'))}
export default function L(){return(<main className='wrap'><div className='card'><h2>שפות</h2><ul>{data.map((l,i)=>(<li key={i}><Link href={'/languages/'+slug(l.english)}>{l.name}</Link></li>))}</ul></div></main>)}
