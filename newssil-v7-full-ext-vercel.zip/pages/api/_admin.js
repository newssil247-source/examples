
import admin from 'firebase-admin';
let cached = global._nsAdmin || { app:null, db:null };
export function initAdmin(){
  if(!cached.app){
    const key = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g,'\n');
    cached.app = admin.apps[0] || admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: key
      })
    });
    cached.db = admin.firestore();
    global._nsAdmin = cached;
  }
  return cached;
}
export { default as adminLib } from 'firebase-admin';
