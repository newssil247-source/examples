
import { initAdmin } from './_admin'
export default async function handler(req,res){
  try{
    const limit = Math.min(parseInt(req.query.limit||'30',10), 100)
    const region = (req.query.region||'').toUpperCase()
    const { db } = initAdmin()
    let q = db.collection('articles').orderBy('createdAt','desc')
    if(region) q = q.where('region','==',region)
    const snap = await q.limit(limit).get()
    const items = snap.docs.map(d=>({ id:d.id, ...d.data() }))
    res.status(200).json({ items })
  }catch(e){
    res.status(200).json({ items: [
      { title:'דוגמה: כתבה 1', summary:'זהו תקציר.', topic:'general', region:'IL' },
      { title:'דוגמה: כתבה 2', summary:'זהו תקציר נוסף.', topic:'tech', region:'US' }
    ]})
  }
}
