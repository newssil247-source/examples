
import Stripe from 'stripe'
export default async function handler(req,res){
  try{
    const sk=process.env.STRIPE_SECRET_KEY; if(!sk) return res.status(200).json({error:'missing STRIPE_SECRET_KEY'})
    const stripe=new Stripe(sk)
    const session=await stripe.checkout.sessions.create({
      mode:'subscription',
      line_items:[{ price: process.env.STRIPE_PRICE_ID || 'price_XXXX', quantity:1 }],
      success_url: process.env.SUCCESS_URL || 'http://localhost:3000/premium?ok=1',
      cancel_url: process.env.CANCEL_URL || 'http://localhost:3000/premium/upgrade?canceled=1'
    })
    res.status(200).json({url: session.url})
  }catch(e){ res.status(200).json({error:e.message}) }
}
