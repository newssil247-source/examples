
import { useState } from 'react'
export default function Upgrade(){
  const [status,setStatus]=useState('')
  return (<main className='wrap'><div className='card'><h2>שדרוג למנוי</h2>
    <button className='btn' onClick={async()=>{ setStatus('יוצר Session...'); const r=await fetch('/api/payments/create-session',{method:'POST'}); const j=await r.json(); if(j.url) window.location=j.url; else setStatus(j.error||'חסר מפתח Stripe') }}>קנה מנוי</button>
    <div>{status}</div>
  </div></main>)
}
