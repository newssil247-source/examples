
/* global self, importScripts */
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');
self.addEventListener('install', ()=>self.skipWaiting());
self.addEventListener('activate', ()=>self.clients.claim());
firebase.initializeApp({
  apiKey: "__API__KEY__", authDomain: "__AUTH__DOMAIN__", projectId: "__PROJECT__ID__",
  storageBucket: "__BUCKET__", messagingSenderId: "__SENDER__ID__", appId: "__APP__ID__"
});
const messaging = firebase.messaging();
messaging.onBackgroundMessage(function(payload) {
  const title = payload.notification?.title || 'Newssil';
  const options = { body: payload.notification?.body || '', icon: '/icon-192.png' };
  self.registration.showNotification(title, options);
});
